# LootSwap — free gaming marketplace starter

This is a **front-end demo**, not a live multi-user marketplace. It includes sample listings, search, filters and a form that adds a listing in the current browser session. Other visitors cannot see listings you add.

## Step 1 — Download and unzip
Unzip `lootloop-website.zip` on your computer.

## Step 2 — Preview it
Open the `index.html` file in Chrome, Edge, Firefox or Safari. It should work without installing anything.

## Step 3 — Put it online for free with GitHub Pages
1. Create/sign in to a GitHub account if you meet GitHub's current age and account requirements.
2. Create a new **public** repository named `lootloop`.
3. Upload `index.html` to the repository's main/root folder.
4. Open the repository's **Settings → Pages**.
5. Under the build/deployment source, choose **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)` folder, then save.
7. Wait for GitHub Pages to publish. The Pages screen will show the website address.

GitHub's menus can change; follow its current Pages documentation if labels differ:
https://docs.github.com/en/pages/quickstart

## What works now
- Responsive homepage
- Sample game categories
- Search and filters
- Add a demo listing
- Listing details pop-up

## What does NOT work yet
- Accounts / sign-in
- Listings shared between visitors
- Real messaging or trade completion
- Payments
- Moderation dashboard

Those features require a secure backend, privacy protections, moderation, and careful checks of each game's terms. Do not collect passwords, account credentials, payment details, addresses or other sensitive information. Do not enable buying/selling of items or accounts where the game publisher prohibits it. Start with a community information/listing demo and check the rules for each game before allowing trades.

## Important for a 15-year-old site owner
Check the current age and terms for any hosting, database, payment, or marketplace service before creating an account. Do not enter a false age or bypass an age restriction. You can build and preview this static demo without connecting payments or collecting visitor information.
